package chess;

public class Pawn extends Piece {

    public Pawn(Chess.Player player, int rank, char file) {
        super(player, rank, file);
    }

    @Override
    public boolean isValidMove(int startRank, int startFile, int endRank, int endFile, ReturnPiece[][] board) {
        int direction = (player == Chess.Player.white) ? 1 : -1;
        int rankDiff = endRank - startRank;
        int fileDiff = Math.abs(startFile - endFile);

        // Standard pawn move (one square forward)
        if (fileDiff == 0 && rankDiff == direction && board[endRank][endFile] == null) {
            return true;
        }

        // First move (two squares forward)
        if (fileDiff == 0 && rankDiff == 2 * direction && startRank == (player == Chess.Player.white ? 1 : 6)
                && board[startRank + direction][startFile] == null && board[endRank][endFile] == null) {
            return true;
        }

        // Capture move (diagonal)
        if (fileDiff == 1 && rankDiff == direction && board[endRank][endFile] != null) {
            return true;
        }

        return false;
    }
}
