package chess;

public class MoveValidator {

    public static boolean isValidMove(ReturnPiece piece, String move, ReturnPiece[][] board) {
        int sf = piece.pieceFile.ordinal();
        int sr = piece.pieceRank - 1;
        int df = move.charAt(0) - 'a';
        int dr = Character.getNumericValue(move.charAt(1)) - 1;

        switch (piece.pieceType) {
            case WP:
                return validatePawnMove(sf, sr, df, dr, true, board);
            case BP:
                return validatePawnMove(sf, sr, df, dr, false, board);
            case WR: case BR:
                return validateRookMove(sf, sr, df, dr, board);
            case WN: case BN:
                return validateKnightMove(sf, sr, df, dr);
            case WB: case BB:
                return validateBishopMove(sf, sr, df, dr, board);
            case WQ: case BQ:
                return validateQueenMove(sf, sr, df, dr, board);
            case WK: case BK:
                return validateKingMove(sf, sr, df, dr, board);
            default:
                return false;
        }
    }

    public static boolean validatePawnMove(int sf, int sr, int df, int dr, boolean isWhite, ReturnPiece[][] board) {
        int direction = isWhite ? 1 : -1;
        if (sf == df && dr - sr == direction && board[dr][df] == null) return true;
        if (sf == df && dr - sr == 2 * direction && sr == (isWhite ? 1 : 6) && board[sr + direction][sf] == null) return true;
        if (Math.abs(sf - df) == 1 && dr - sr == direction && board[dr][df] != null) return true;
        return false;
    }

    public static boolean validateRookMove(int sf, int sr, int df, int dr, ReturnPiece[][] board) {
        if (sf != df && sr != dr) return false; // Rook moves only straight

        int stepF = (df > sf) ? 1 : (df < sf) ? -1 : 0;
        int stepR = (dr > sr) ? 1 : (dr < sr) ? -1 : 0;
        int f = sf + stepF, r = sr + stepR;

        while (f != df || r != dr) {
            if (board[r][f] != null) return false;
            f += stepF;
            r += stepR;
        }
        return true;
    }

    public static boolean validateBishopMove(int sf, int sr, int df, int dr, ReturnPiece[][] board) {
        if (Math.abs(df - sf) != Math.abs(dr - sr)) return false; // Must move diagonally

        int stepF = (df > sf) ? 1 : -1;
        int stepR = (dr > sr) ? 1 : -1;
        int f = sf + stepF, r = sr + stepR;

        while (f != df && r != dr) {
            if (board[r][f] != null) return false;
            f += stepF;
            r += stepR;
        }
        return true;
    }

    public static boolean validateQueenMove(int sf, int sr, int df, int dr, ReturnPiece[][] board) {
        return validateRookMove(sf, sr, df, dr, board) || validateBishopMove(sf, sr, df, dr, board);
    }

    public static boolean validateKnightMove(int sf, int sr, int df, int dr) {
        return (Math.abs(sf - df) == 2 && Math.abs(sr - dr) == 1) || (Math.abs(sf - df) == 1 && Math.abs(sr - dr) == 2);
    }

    public static boolean validateKingMove(int sf, int sr, int df, int dr, ReturnPiece[][] board) {
        return Math.abs(sf - df) <= 1 && Math.abs(sr - dr) <= 1;
    }

    public static boolean validatePromotion(ReturnPiece piece, int rank) {
        return (piece.pieceType == ReturnPiece.PieceType.WP && rank == 7) ||
               (piece.pieceType == ReturnPiece.PieceType.BP && rank == 0);
    }
}
