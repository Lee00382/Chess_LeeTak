package chess;

public class GameController {
    public static ReturnPlay.Message getGameState(Board board, Chess.Player player) {
        if (isCheckmate(board, player)) {
            return player == Chess.Player.white ? ReturnPlay.Message.CHECKMATE_BLACK_WINS : ReturnPlay.Message.CHECKMATE_WHITE_WINS;
        }
        if (isCheck(board, player)) {
            return ReturnPlay.Message.CHECK;
        }
        return null;
    }

    public static boolean isCheck(Board board, Chess.Player player) {
        ReturnPiece king = findKing(board, player);
        if (king == null) return false;

        for (ReturnPiece piece : board.getPiecesOnBoard()) {
            if (!piece.pieceType.toString().startsWith(player == Chess.Player.white ? "W" : "B")) {
                if (MoveValidator.isValidMove(piece, king.pieceFile.toString() + king.pieceRank, board.getBoardArray())) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean isCheckmate(Board board, Chess.Player player) {
        if (!isCheck(board, player)) return false;

        for (ReturnPiece piece : board.getPiecesOnBoard()) {
            if (piece.pieceType.toString().startsWith(player == Chess.Player.white ? "W" : "B")) {
                for (int r = 1; r <= 8; r++) {
                    for (char c = 'a'; c <= 'h'; c++) {
                        if (MoveValidator.isValidMove(piece, c + Integer.toString(r), board.getBoardArray())) {
                            return false;
                        }
                    }
                }
            }
        }
        return true;
    }

    private static ReturnPiece findKing(Board board, Chess.Player player) {
        for (ReturnPiece piece : board.getPiecesOnBoard()) {
            if ((player == Chess.Player.white && piece.pieceType == ReturnPiece.PieceType.WK) ||
                (player == Chess.Player.black && piece.pieceType == ReturnPiece.PieceType.BK)) {
                return piece;
            }
        }
        return null;
    }
}
