package chess;

public class Chess {
    private static Board board;

    enum Player { white, black }

    public static void start() {
        board = new Board();
    }

    public static ReturnPlay play(String move) {
        ReturnPlay result = new ReturnPlay();
        
        if (board.makeMove(move)) {
            result.piecesOnBoard = board.getPiecesOnBoard();
            result.message = board.getGameState();
        } else {
            result.message = ReturnPlay.Message.ILLEGAL_MOVE;
        }
        
        return result;
    }
}
