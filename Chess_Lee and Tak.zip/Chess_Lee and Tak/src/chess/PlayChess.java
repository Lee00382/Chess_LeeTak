package chess;

import java.util.Scanner;

public class PlayChess {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Chess.start();

        String line = sc.nextLine();
        while (!line.equals("quit")) {
            if (line.equals("reset")) {
                Chess.start();
                System.out.println();
                line = sc.nextLine();
                continue;
            }

            if (line.contains("draw?")) {
                System.out.println("Draw offered. If opponent agrees, type 'draw'.");
                line = sc.nextLine();
                if (line.equals("draw")) {
                    System.out.println("Game ends in a draw.");
                    break;
                }
                continue;
            }

            ReturnPlay res = Chess.play(line);
            if (res.message != null) {
                System.out.println("\n" + res.message);
            }
            System.out.println();
            line = sc.nextLine();
        }
        sc.close();
    }
}
