package chess;

import java.util.ArrayList;

public class Board {
    private ReturnPiece[][] board;
    private Chess.Player currentPlayer;

    public Board() {
        initializeBoard();
    }

    private void initializeBoard() {
        board = new ReturnPiece[8][8];
        currentPlayer = Chess.Player.white;
        setupPieces();
    }

    private void setupPieces() {
        String[] backRank = {"R", "N", "B", "Q", "K", "B", "N", "R"};

        for (int i = 0; i < 8; i++) {
            board[1][i] = new ReturnPiece(ReturnPiece.PieceType.WP, getFile(i), 2);
            board[6][i] = new ReturnPiece(ReturnPiece.PieceType.BP, getFile(i), 7);
        }

        for (int i = 0; i < 8; i++) {
            board[0][i] = new ReturnPiece(getPieceType("W" + backRank[i]), getFile(i), 1);
            board[7][i] = new ReturnPiece(getPieceType("B" + backRank[i]), getFile(i), 8);
        }
    }

    private ReturnPiece.PieceType getPieceType(String piece) {
        switch (piece) {
            case "WP": return ReturnPiece.PieceType.WP;
            case "WR": return ReturnPiece.PieceType.WR;
            case "WN": return ReturnPiece.PieceType.WN;
            case "WB": return ReturnPiece.PieceType.WB;
            case "WQ": return ReturnPiece.PieceType.WQ;
            case "WK": return ReturnPiece.PieceType.WK;
            case "BP": return ReturnPiece.PieceType.BP;
            case "BR": return ReturnPiece.PieceType.BR;
            case "BN": return ReturnPiece.PieceType.BN;
            case "BB": return ReturnPiece.PieceType.BB;
            case "BQ": return ReturnPiece.PieceType.BQ;
            case "BK": return ReturnPiece.PieceType.BK;
            default: throw new IllegalArgumentException("Invalid piece type");
        }
    }

    private ReturnPiece.PieceFile getFile(int index) {
        return ReturnPiece.PieceFile.values()[index];
    }

    public ArrayList<ReturnPiece> getPiecesOnBoard() {
        ArrayList<ReturnPiece> pieces = new ArrayList<>();
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                if (board[r][c] != null) {
                    pieces.add(board[r][c]);
                }
            }
        }
        return pieces;
    }

    public boolean makeMove(String move) {
        String[] parts = move.split(" ");
        if (parts.length != 2) return false;

        ReturnPiece startPiece = getPieceAt(parts[0]);
        if (startPiece == null || !MoveValidator.isValidMove(startPiece, parts[1], board)) return false;

        movePiece(startPiece, parts[1]);
        currentPlayer = (currentPlayer == Chess.Player.white) ? Chess.Player.black : Chess.Player.white;
        return true;
    }

    private ReturnPiece getPieceAt(String pos) {
        int file = pos.charAt(0) - 'a';
        int rank = Character.getNumericValue(pos.charAt(1)) - 1;
        return board[rank][file];
    }

    private void movePiece(ReturnPiece piece, String dest) {
        int oldFile = piece.pieceFile.ordinal();
        int oldRank = piece.pieceRank - 1;
        int newFile = dest.charAt(0) - 'a';
        int newRank = Character.getNumericValue(dest.charAt(1)) - 1;

        board[oldRank][oldFile] = null;
        piece.pieceRank = newRank + 1;
        piece.pieceFile = getFile(newFile);

        // Handle pawn promotion
        if (MoveValidator.validatePromotion(piece, newRank)) {
            piece.pieceType = (piece.pieceType == ReturnPiece.PieceType.WP) ? ReturnPiece.PieceType.WQ : ReturnPiece.PieceType.BQ;
        }

        board[newRank][newFile] = piece;
    }

    public ReturnPlay.Message getGameState() {
        return GameController.getGameState(this, currentPlayer);
    }

    public ReturnPiece[][] getBoardArray() {
        return board;
    }
}
