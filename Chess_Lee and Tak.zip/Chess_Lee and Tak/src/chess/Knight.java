package chess;

public class Knight extends Piece {

    public Knight(Chess.Player player, int rank, char file) {
        super(player, rank, file);
    }

    @Override
    public boolean isValidMove(int startRank, int startFile, int endRank, int endFile, ReturnPiece[][] board) {
        int rankDiff = Math.abs(startRank - endRank);
        int fileDiff = Math.abs(startFile - endFile);

        // Knight moves in an "L" shape
        return (rankDiff == 2 && fileDiff == 1) || (rankDiff == 1 && fileDiff == 2);
    }
}
