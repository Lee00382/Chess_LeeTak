package chess;

import java.util.ArrayList;

class ReturnPlay {
    enum Message {ILLEGAL_MOVE, DRAW, 
                  RESIGN_BLACK_WINS, RESIGN_WHITE_WINS, 
                  CHECK, CHECKMATE_BLACK_WINS, CHECKMATE_WHITE_WINS, 
                  STALEMATE};

    ArrayList<ReturnPiece> piecesOnBoard;
    Message message;
}
