package chess;

public class Bishop extends Piece {

    public Bishop(Chess.Player player, int rank, char file) {
        super(player, rank, file);
    }

    @Override
    public boolean isValidMove(int startRank, int startFile, int endRank, int endFile, ReturnPiece[][] board) {
        int rankDiff = Math.abs(startRank - endRank);
        int fileDiff = Math.abs(startFile - endFile);

        // Bishop moves diagonally
        if (rankDiff == fileDiff) {
            int rankStep = (endRank > startRank) ? 1 : -1;
            int fileStep = (endFile > startFile) ? 1 : -1;

            int currentRank = startRank + rankStep;
            int currentFile = startFile + fileStep;

            while (currentRank != endRank && currentFile != endFile) {
                if (board[currentRank][currentFile] != null) {
                    return false; // Blocked path
                }
                currentRank += rankStep;
                currentFile += fileStep;
            }
            return true;
        }
        return false;
    }
}
