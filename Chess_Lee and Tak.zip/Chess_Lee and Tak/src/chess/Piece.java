package chess;

public abstract class Piece {
    protected Chess.Player player;
    protected int rank;
    protected char file;

    public Piece(Chess.Player player, int rank, char file) {
        this.player = player;
        this.rank = rank;
        this.file = file;
    }

    public abstract boolean isValidMove(int startRank, int startFile, int endRank, int endFile, ReturnPiece[][] board);

    public Chess.Player getPlayer() {
        return player;
    }

    public char getFile() {
        return file;
    }

    public int getRank() {
        return rank;
    }
}
