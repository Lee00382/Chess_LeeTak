package chess;

public class Rook extends Piece {

    public Rook(Chess.Player player, int rank, char file) {
        super(player, rank, file);
    }

    @Override
    public boolean isValidMove(int startRank, int startFile, int endRank, int endFile, ReturnPiece[][] board) {
        return MoveValidator.validateRookMove(startFile, startRank, endFile, endRank, board);
    }
}
