package chess;

public class King extends Piece {

    public King(Chess.Player player, int rank, char file) {
        super(player, rank, file);
    }

    @Override
    public boolean isValidMove(int startRank, int startFile, int endRank, int endFile, ReturnPiece[][] board) {
        int rankDiff = Math.abs(startRank - endRank);
        int fileDiff = Math.abs(startFile - endFile);

        // Standard king movement: one step in any direction
        if (rankDiff <= 1 && fileDiff <= 1) {
            return true;
        }

        // Castling conditions
        if (validateCastling(startRank, startFile, endRank, endFile, board)) {
            return true;
        }

        return false;
    }

    private boolean validateCastling(int startRank, int startFile, int endRank, int endFile, ReturnPiece[][] board) {
        if (startRank != endRank || Math.abs(startFile - endFile) != 2) {
            return false; // King moves two spaces horizontally for castling
        }

        int rookFile = (endFile > startFile) ? 7 : 0; // Right for king-side, left for queen-side
        ReturnPiece rook = board[startRank][rookFile];

        // Ensure the Rook exists and there are no pieces between them
        if (rook != null && (rook.pieceType == ReturnPiece.PieceType.WR || rook.pieceType == ReturnPiece.PieceType.BR)) {
            int step = (endFile > startFile) ? 1 : -1;
            for (int i = startFile + step; i != rookFile; i += step) {
                if (board[startRank][i] != null) return false;
            }
            return true; // Valid castling
        }
        return false;
    }
}
