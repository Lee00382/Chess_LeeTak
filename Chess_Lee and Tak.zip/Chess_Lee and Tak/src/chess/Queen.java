package chess;

public class Queen extends Piece {

    public Queen(Chess.Player player, int rank, char file) {
        super(player, rank, file);
    }

    @Override
    public boolean isValidMove(int startRank, int startFile, int endRank, int endFile, ReturnPiece[][] board) {
        return MoveValidator.validateRookMove(startFile, startRank, endFile, endRank, board) ||
               MoveValidator.validateBishopMove(startFile, startRank, endFile, endRank, board);
    }
}
